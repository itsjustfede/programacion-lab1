#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct
{
    char* key;
    char* value;
} eS;


int main()
{
    FILE* archivo;
    eS estructura[2];
    char clave[10];
    char valor[10];
    int aa=0, bb;


    bb= loadDataFile(archivo, &estructura, aa);
    aa=bb;
    while(!feof(archivo))
    {
        printf("%s----%s", estructura.key, estructura.value);
    };



    return 0;
}


int loadDataFile(char* fileName,eS estructura, int cant)
{
    char clave[10];
    char valor[10];

    fileName= fopen("texto.txt", "r");
    if(fileName==NULL)
    {
        printf("error al abrir el archivo");
        exit(1);
    };
    while(!feof(fileName))
    {
        fscanf(fileName,"%[^=],%[^\n]",clave , valor);
        strcpy(estructura[cant].key, clave);
        strcpy(estructura[cant].value, valor);
        cant++;
    };

   fclose(archivo);

    return cant;



}
