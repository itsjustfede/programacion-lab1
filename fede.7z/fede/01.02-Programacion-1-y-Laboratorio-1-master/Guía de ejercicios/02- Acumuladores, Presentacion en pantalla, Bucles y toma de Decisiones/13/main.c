#include <stdio.h>
#include <stdlib.h>

int main()
{
   int numero=100;

    while(numero>=1)
    {
      printf("%i \n", numero);
      numero--;

    }



    return 0;
}

