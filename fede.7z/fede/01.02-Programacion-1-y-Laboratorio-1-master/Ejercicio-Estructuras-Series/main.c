#include <stdio.h>
#include <stdlib.h>
#include "Series.h"
#include "Clientes.h"

int main()
{

}
