

typedef struct
{
    int legajo;
    char nombre[50];
    float sueldo;
    char eCivil;
    int estado;
} eEmpleado;


//funciones

void mostrarEmpleado(eEmpleado);
void mostrarNomina(eEmpleado[], int);



