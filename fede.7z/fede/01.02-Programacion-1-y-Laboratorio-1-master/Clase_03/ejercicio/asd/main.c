#include <stdio.h>
#include <stdlib.h>


char perdirChar(char texto[]);
char validarChar(char);
char mostrarChar(char, char texto[]);

int main()
{
    int letra1;
    int letra2;

}

char pedirChar(char texto[])
{
    char caracter;

    printf("%s", texto);
    scanf(" %c", &caracter);
}

char validarChar(char)
{

}

char mostrarChar(char, char texto[])
{
    printf("%s %c", texto, caracter);
}
