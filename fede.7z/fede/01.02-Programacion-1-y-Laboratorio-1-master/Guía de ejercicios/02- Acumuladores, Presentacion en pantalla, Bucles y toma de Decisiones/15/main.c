#include <stdio.h>
#include <stdlib.h>

int main()
{
  int numero=1;

    while(numero<=100)
    {
        if(numero%6==0)
        {
            printf("%i \n", numero);
        }

        numero++;

    }
}
