int parserEmployee(FILE* pFile , ArrayList* pArrayListEmployee);
