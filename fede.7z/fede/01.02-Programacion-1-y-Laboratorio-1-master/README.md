# Material educativo Programación I y Laboratorio I

## Tecnicaturas en programación. UTN-FRA

#### Descripción:

En este repositorio se encontrará el material educativo utiliziado en las materias Programación I y Laboratorio I separado clase a clase.
Dentro de cada directorio que corresponde a una clase, se encontrará un archivo README en donde se detallará el contenido de dicha clase, generalmente compuesto por
uno o más apuntes, un videotutorial explicando la resolución de un ejercicio y los archivos del programa resuelto en el video.

#### Contacto:
UTN-FRA. Extensión universitaria. Tecnicaturas en programación. http://www.sistemas-utnfra.com.ar . tecnicaturas@fra.utn.edu.ar

