#include <stdio.h>
#include <stdlib.h>
int sumar(void);

int main()
{
    printf("%d",sumar());
    return 0;
}

int sumar(void)
{
    int numero1;
    int numero2;
    int suma;
    printf("Ingrese el numero 1: ");
    scanf("%d",&numero1);
    printf("Ingrese el numero 2: ");
    scanf("%d",&numero2);
    suma=numero1+numero2;

    return suma;
}
