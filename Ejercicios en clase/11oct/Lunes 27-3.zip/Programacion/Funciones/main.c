#include <stdio.h>
#include <stdlib.h>
void sumar(void);

int main()
{
    sumar();
    return 0;
}

void sumar(void)
{
    int numero1;
    int numero2;
    int suma;
    printf("Ingrese el numero 1: ");
    scanf("%d",&numero1);
    printf("Ingrese el numero 2: ");
    scanf("%d",&numero2);
    suma=numero1+numero2;
    printf("%d",suma);
}




