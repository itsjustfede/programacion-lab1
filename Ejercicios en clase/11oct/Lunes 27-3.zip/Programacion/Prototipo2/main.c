#include <stdio.h>
#include <stdlib.h>
void sumar(int,int);

int main()
{
    int numero1;
    int numero2;

    printf("Ingrese el numero 1: ");
    scanf("%d",&numero1);
    printf("Ingrese el numero 2: ");
    scanf("%d",&numero2);

    sumar(numero1,numero2);
    return 0;
}

void sumar(int x,int y)
{
    int suma;
    suma=x+y;
    printf("%d",suma);
}
