# Clase 12

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* -

#### Video tutoriales:

* https://www.youtube.com/watch?v=tUFK99M59P8&index=12&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

   Al ejercicio de la clase 11 incorporar la siguiente funcionalidad

   5. LISTAR: Realizar un solo listado de los datos ordenados por
              los siguientes criterios:
       o Descripci�n (descendente)
       o Cantidad (ascendente)
   6. INFORMAR:
       A. Los datos del/os producto/s de menor Importe.
       B. Los datos del/os producto/s que superan el valor de precio promedio

   7. MINIMIZAR:
       Realizar las funciones necesarias a fin de minimizar la funci�n main()

- Version: 0.1 del 04 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   manejo de men�
*   manejo de estructuras
*   funcion main() compacta
*   variables y funciones en Ingles