
typedef struct
{
    int idSerie;
    char titulo[50];
    int estado;
    int idSerie;
} eSeries;






