#include <stdio.h>
#include <stdlib.h>
int sumar(int,int);

int main()
{
    int numero1;
    int numero2;
    int suma;
    printf("Ingrese el numero 1: ");
    scanf("%d",&numero1);
    printf("Ingrese el numero 2: ");
    scanf("%d",&numero2);

    suma=sumar(numero1,numero2);
    printf("%d",suma);
    return 0;
}

int sumar(int x,int y)
{
    int suma;
    suma=x+y;
    return suma;
}
