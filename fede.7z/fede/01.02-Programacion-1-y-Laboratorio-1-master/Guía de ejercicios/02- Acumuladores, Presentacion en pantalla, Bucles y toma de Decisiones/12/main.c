#include <stdio.h>
#include <stdlib.h>

int main()
{

    int numero=1;

    while(numero<=100)
    {
      printf("%i \n", numero);
      numero++;

    }



    return 0;
}
