

typedef struct
{
    int idCliente;
    char nombre[50];
    int temporadas;
    char genero[40];
    int estado;

} eClientes;
