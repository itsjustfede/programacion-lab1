#include <stdio.h>
#include <stdlib.h>

int sumar(int, int);

int main()
{
    int total;

    total = sumar(5,4);

    printf("\n");
    return 0;
}

int sumar(int num1, int num2){

    return num1 + num2;

}
